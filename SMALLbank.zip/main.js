function clickme() {
  var userId = document.getElementById("userId").value
  if (userId == "A18509836") {
    window.location = "/A18509836.html";
  }else if(userId == "B18519836"){
    window.location = "/B18519836.html"
  }else if (userId =="C18535836") {
  window.location = "/C18535836.html"
}else if(userId == "D18539800"){
  window.location = "/D18539800.html"
}else if(userId == "E18539836"){
  window.location = "/E18539836.html"
}else if (userId == "F18539876") {
  window.location = "/F18539876.html"
}else if (userId == "G18539899") {
  window.location = "/G18539899.html"
}else if (userId == "H18559836") {
  window.location = "/H18559836.html"
}else if (userId == "J28539836") {
  window.location = "/J28539836.html"
}else{
  alert("Numéro de carte inconnue, svp veuillez réessayer plus tard !")
}
}