function withdraw(){
  alert("Svp, rendez-vous à l'agence MAGICbank, ou ecriver au magicbank52@gmail.com, pour plus d'informations appeler le numéro +2250506588720")
}